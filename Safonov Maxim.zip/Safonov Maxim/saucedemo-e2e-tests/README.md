# SauceDemo E2E Test Suite

End-to-end test suite for [SauceDemo](https://www.saucedemo.com/) built with **Playwright** and **TypeScript**.

## Test Scenarios

| #   | Scenario | User | What it validates |
| --- | -------- | ---- | ----------------- |
| 1   | **Complete order placement** | `standard_user` | Login → verify 6 products → add 3 items → cart contents & prices → shipping form → overview (subtotal + tax + total math) → confirmation → cart empties |
| 2   | **Checkout form validation** | `standard_user` | Empty-cart checkout access, field-by-field required errors (First Name → Last Name → Postal Code), whitespace-only input (**known bug**: app accepts spaces) |
| 3   | **Product sorting** | `standard_user` | All 4 filters — Name A→Z, Name Z→A, Price Low→High, Price High→Low — verified programmatically with correct order + no missing products |
| 4   | **problem_user regressions** | `problem_user` | Sorting filters have no effect (**bug**), Last Name field overwrites First Name (**field sync bug**), user cannot complete checkout correctly |

### Documented Defects

| Bug | User | Observed Behavior | Expected Behavior |
| --- | ---- | ----------------- | ----------------- |
| Whitespace accepted in checkout fields | `standard_user` | Spaces-only input passes validation, order goes through | Fields should reject whitespace-only values |
| Sorting has no effect | `problem_user` | Product order stays the same regardless of selected filter | Products should reorder by name or price |
| Field data sync in checkout | `problem_user` | Typing in Last Name also populates First Name | Each field should store only its own value |

## Setup

```bash
# Install dependencies
npm install

# Install Playwright browsers
npx playwright install --with-deps chromium
```

## Running Tests

```bash
# Run all tests (headless)
npm test

# Run in headed mode (see the browser)
npm run test:headed

# Open interactive UI mode
npm run test:ui

# View the HTML report after a run
npm run test:report
```

## Project Structure

```
├── playwright.config.ts        # Playwright configuration
├── tests/
│   ├── pages/                  # Page Object Models
│   │   ├── LoginPage.ts
│   │   ├── InventoryPage.ts
│   │   ├── CartPage.ts
│   │   └── CheckoutPage.ts
│   └── saucedemo.spec.ts       # All 4 E2E scenarios
```

## Design Decisions

- **Playwright + TypeScript** — modern framework with built-in auto-waits, strong typing, and no flaky `sleep()` calls.
- **Page Object Model** — selectors and page interactions isolated in reusable classes; tests stay readable and easy to maintain.
- **`data-test` attribute selectors** — the app exposes `data-test` attributes on key elements, making locators resilient to CSS/styling changes.
- **Cross-user coverage** — tests run against both `standard_user` (happy path) and `problem_user` (regression/bug detection) to demonstrate testing across user personas.
- **Bug documentation in tests** — known defects (whitespace acceptance, field sync, broken sorting) are explicitly documented with `// BUG:` comments and clear expected-vs-actual descriptions, making them easy to track as the application evolves.
- **Price math verification** — the checkout test verifies `subtotal = sum of items`, `tax > 0`, and `total = subtotal + tax` to catch calculation regressions.

## Assumptions

- Tests run against the live SauceDemo site at `https://www.saucedemo.com/`.
- Credentials (`standard_user` / `problem_user` with password `secret_sauce`) remain valid.
- Product prices match those currently on the site ($29.99, $9.99, $7.99, $49.99, etc.).
- Only Chromium is configured by default; additional browsers can be added in `playwright.config.ts`.
- No CI pipeline is included, but the config has `CI`-aware settings (retries, single worker) ready to use.
