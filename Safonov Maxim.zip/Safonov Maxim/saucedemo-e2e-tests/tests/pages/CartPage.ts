import { type Page, type Locator } from "@playwright/test";

export class CartPage {
  readonly page: Page;
  readonly cartItems: Locator;
  readonly checkoutButton: Locator;
  readonly continueShoppingButton: Locator;
  readonly itemNames: Locator;
  readonly itemPrices: Locator;
  readonly itemQuantities: Locator;

  constructor(page: Page) {
    this.page = page;
    this.cartItems = page.locator('[data-test="inventory-item"]');
    this.checkoutButton = page.locator('[data-test="checkout"]');
    this.continueShoppingButton = page.locator(
      '[data-test="continue-shopping"]'
    );
    this.itemNames = page.locator('[data-test="inventory-item-name"]');
    this.itemPrices = page.locator('[data-test="inventory-item-price"]');
    this.itemQuantities = page.locator('[data-test="item-quantity"]');
  }

  async getItemNames(): Promise<string[]> {
    return this.itemNames.allTextContents();
  }

  async getItemPrices(): Promise<string[]> {
    return this.itemPrices.allTextContents();
  }

  async getItemQuantities(): Promise<string[]> {
    return this.itemQuantities.allTextContents();
  }

  async getItemPriceByName(itemName: string): Promise<string> {
    const item = this.page.locator('[data-test="inventory-item"]', {
      hasText: itemName,
    });
    return item.locator('[data-test="inventory-item-price"]').innerText();
  }

  async removeItemByName(itemName: string) {
    const item = this.page.locator('[data-test="inventory-item"]', {
      hasText: itemName,
    });
    await item.locator("button", { hasText: "Remove" }).click();
  }

  async proceedToCheckout() {
    await this.checkoutButton.click();
  }
}
