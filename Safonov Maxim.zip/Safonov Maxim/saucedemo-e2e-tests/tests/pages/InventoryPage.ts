import { type Page, type Locator } from "@playwright/test";

export class InventoryPage {
  readonly page: Page;
  readonly title: Locator;
  readonly inventoryItems: Locator;
  readonly cartBadge: Locator;
  readonly cartLink: Locator;
  readonly sortDropdown: Locator;
  readonly burgerMenuButton: Locator;
  readonly logoutLink: Locator;
  readonly itemNames: Locator;
  readonly itemPrices: Locator;
  readonly itemDescriptions: Locator;
  readonly itemImages: Locator;

  constructor(page: Page) {
    this.page = page;
    this.title = page.locator('[data-test="title"]');
    this.inventoryItems = page.locator('[data-test="inventory-item"]');
    this.cartBadge = page.locator('[data-test="shopping-cart-badge"]');
    this.cartLink = page.locator('[data-test="shopping-cart-link"]');
    this.sortDropdown = page.locator('[data-test="product-sort-container"]');
    this.burgerMenuButton = page.getByRole("button", { name: "Open Menu" });
    this.logoutLink = page.locator('[data-test="logout-sidebar-link"]');
    this.itemNames = page.locator('[data-test="inventory-item-name"]');
    this.itemPrices = page.locator('[data-test="inventory-item-price"]');
    this.itemDescriptions = page.locator('[data-test="inventory-item-desc"]');
    this.itemImages = page.locator("img.inventory_item_img");
  }

  async addItemToCartByName(itemName: string) {
    const item = this.page.locator('[data-test="inventory-item"]', {
      hasText: itemName,
    });
    await item.locator("button", { hasText: "Add to cart" }).click();
  }

  async removeItemByName(itemName: string) {
    const item = this.page.locator('[data-test="inventory-item"]', {
      hasText: itemName,
    });
    await item.locator("button", { hasText: "Remove" }).click();
  }

  getAddToCartButton(itemName: string): Locator {
    const item = this.page.locator('[data-test="inventory-item"]', {
      hasText: itemName,
    });
    return item.locator("button");
  }

  async clickProductLink(itemName: string) {
    await this.page
      .locator('[data-test="inventory-item-name"]', { hasText: itemName })
      .click();
  }

  async getItemNames(): Promise<string[]> {
    return this.itemNames.allTextContents();
  }

  async getItemPrices(): Promise<number[]> {
    const priceTexts = await this.itemPrices.allTextContents();
    return priceTexts.map((text) => parseFloat(text.replace("$", "")));
  }

  async getItemPriceByName(itemName: string): Promise<string> {
    const item = this.page.locator('[data-test="inventory-item"]', {
      hasText: itemName,
    });
    return item.locator('[data-test="inventory-item-price"]').innerText();
  }

  async sortBy(value: string) {
    await this.sortDropdown.selectOption(value);
  }

  async goToCart() {
    await this.cartLink.click();
  }

  async logout() {
    await this.burgerMenuButton.click();
    await this.logoutLink.click();
  }
}
