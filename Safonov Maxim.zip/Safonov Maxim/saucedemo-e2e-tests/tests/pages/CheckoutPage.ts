import { type Page, type Locator } from "@playwright/test";

export class CheckoutPage {
  readonly page: Page;
  readonly firstNameInput: Locator;
  readonly lastNameInput: Locator;
  readonly postalCodeInput: Locator;
  readonly continueButton: Locator;
  readonly finishButton: Locator;
  readonly cancelButton: Locator;
  readonly errorMessage: Locator;
  readonly completeHeader: Locator;
  readonly completeText: Locator;
  readonly summaryTotal: Locator;
  readonly subtotalLabel: Locator;
  readonly taxLabel: Locator;
  readonly backHomeButton: Locator;
  readonly overviewItems: Locator;
  readonly overviewItemNames: Locator;
  readonly overviewItemPrices: Locator;

  constructor(page: Page) {
    this.page = page;
    this.firstNameInput = page.locator('[data-test="firstName"]');
    this.lastNameInput = page.locator('[data-test="lastName"]');
    this.postalCodeInput = page.locator('[data-test="postalCode"]');
    this.continueButton = page.locator('[data-test="continue"]');
    this.finishButton = page.locator('[data-test="finish"]');
    this.cancelButton = page.locator('[data-test="cancel"]');
    this.errorMessage = page.locator('[data-test="error"]');
    this.completeHeader = page.locator('[data-test="complete-header"]');
    this.completeText = page.locator('[data-test="complete-text"]');
    this.summaryTotal = page.locator('[data-test="total-label"]');
    this.subtotalLabel = page.locator('[data-test="subtotal-label"]');
    this.taxLabel = page.locator('[data-test="tax-label"]');
    this.backHomeButton = page.locator('[data-test="back-to-products"]');
    this.overviewItems = page.locator('[data-test="inventory-item"]');
    this.overviewItemNames = page.locator('[data-test="inventory-item-name"]');
    this.overviewItemPrices = page.locator(
      '[data-test="inventory-item-price"]'
    );
  }

  async fillShippingInfo(
    firstName: string,
    lastName: string,
    postalCode: string
  ) {
    await this.firstNameInput.fill(firstName);
    await this.lastNameInput.fill(lastName);
    await this.postalCodeInput.fill(postalCode);
  }

  async continue() {
    await this.continueButton.click();
  }

  async finish() {
    await this.finishButton.click();
  }

  async getOverviewItemNames(): Promise<string[]> {
    return this.overviewItemNames.allTextContents();
  }

  async getSubtotalValue(): Promise<number> {
    const text = await this.subtotalLabel.innerText();
    return parseFloat(text.replace(/[^0-9.]/g, ""));
  }

  async getTaxValue(): Promise<number> {
    const text = await this.taxLabel.innerText();
    return parseFloat(text.replace(/[^0-9.]/g, ""));
  }

  async getTotalValue(): Promise<number> {
    const text = await this.summaryTotal.innerText();
    return parseFloat(text.replace(/[^0-9.]/g, ""));
  }
}
